-- PlaySolo.lua for Dynablox
local Visit = game:service("Visit")
local Players = game:service("Players")
local RunService = game:service("RunService")

-- 1. Попытка загрузить конфиг от лаунчера
local config = nil
local ok, err = pcall(function()
    local loadFunc = loadfile("cosmetics.lua")
    if loadFunc then
        return loadFunc()
    end
end)

if ok and type(config) == "table" then
    print("[Dynablox] Cosmetics loaded successfully!")
else
    print("[Dynablox] Config not found or invalid. Using defaults.")
    config = { 
        colors = { torso="Bright blue", head="Bright yellow", arms="Bright orange", legs="Bright green" },
        assets = {} 
    }
end

local player = game.Players.LocalPlayer
if not player then
    player = game.Players:createLocalPlayer(0)
end

local function waitForChild(parent, childName)
    local child
    while true do
        child = parent:findFirstChild(childName)
        if child then break else parent.ChildAdded:wait() end
    end
    return child
end

-- 2. Функция применения косметики
local function ApplyCosmetics(character)
    if not character then return end
    
    local head = character:FindFirstChild("Head")
    local torso = character:FindFirstChild("Torso")
    
    -- Применяем ЦВЕТА
    if torso and config.colors.torso then torso.BrickColor = BrickColor.new(config.colors.torso) end
    if head and config.colors.head then head.BrickColor = BrickColor.new(config.colors.head) end
    
    for _, partName in pairs({"Left Arm", "Right Arm"}) do
        local arm = character:FindFirstChild(partName)
        if arm and config.colors.arms then arm.BrickColor = BrickColor.new(config.colors.arms) end
    end
    
    for _, partName in pairs({"Left Leg", "Right Leg"}) do
        local leg = character:FindFirstChild(partName)
        if leg and config.colors.legs then leg.BrickColor = BrickColor.new(config.colors.legs) end
    end

    -- Применяем ЛИЦО
    if head and config.assets.face_url then
        local oldFace = head:FindFirstChild("DynabloxFace")
        if oldFace then oldFace:Destroy() end
        
        local decal = Instance.new("Decal")
        decal.Name = "DynabloxFace"
        decal.Face = Enum.NormalId.Front
        decal.Texture = config.assets.face_url
        decal.Parent = head
    end

    -- Применяем ФУТБОЛКУ
    if torso and config.assets.tshirt_url then
        local oldTshirt = torso:FindFirstChild("DynabloxTShirt")
        if oldTshirt then oldTshirt:Destroy() end
        
        local decal = Instance.new("Decal")
        decal.Name = "DynabloxTShirt"
        decal.Face = Enum.NormalId.Front
        decal.Texture = config.assets.tshirt_url
        decal.Parent = torso
    end

    -- Применяем ШТАНЫ
    local pantsObj = character:FindFirstChildOfClass("Pants")
    if not pantsObj and config.assets.pants_url then
         pantsObj = Instance.new("Pants")
         pantsObj.Parent = character
    end
    if pantsObj and config.assets.pants_url then
        pantsObj.PantsTemplate = config.assets.pants_url
    end
end

local function onChanged(property)
    if property == "Character" then
        local humanoid = waitForChild(player.Character, "Humanoid")
        
        wait(0.5) -- Небольшая пауза для гарантированной загрузки частей тела
        ApplyCosmetics(player.Character)

        humanoid.Died:connect(function ()
            wait(5)
            player:LoadCharacter()
        end)
    end
end

player.Changed:connect(onChanged)
player:LoadCharacter()

-- Start the game.
RunService:run()