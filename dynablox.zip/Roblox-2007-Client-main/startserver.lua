-- StartServer.lua for Dynablox
local NetworkServer = game:service("NetworkServer")
local RunService = game:service("RunService")

print("[Dynablox] Starting Network Server on port 53640...")
NetworkServer:start(53640)

-- Сервер просто хостит мир. Косметика применяется на стороне каждого клиента.
RunService:run()