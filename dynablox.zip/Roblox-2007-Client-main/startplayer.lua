-- StartPlayer.lua for Dynablox
local Visit = game:service("Visit")
local Players = game:service("Players")
local NetworkClient = game:service("NetworkClient")

-- Загружаем конфиг (тот же код, что и в PlaySolo)
local config = nil
local ok, err = pcall(function()
    local loadFunc = loadfile("cosmetics.lua")
    if loadFunc then return loadFunc() end
end)
if not ok or type(config) ~= "table" then
    config = { colors={}, assets={} }
end

local function ApplyCosmetics(character)
    if not character then return end
    local head = character:FindFirstChild("Head")
    local torso = character:FindFirstChild("Torso")
    
    if torso and config.colors.torso then torso.BrickColor = BrickColor.new(config.colors.torso) end
    if head and config.colors.head then head.BrickColor = BrickColor.new(config.colors.head) end
    
    if head and config.assets.face_url then
        local decal = Instance.new("Decal")
        decal.Name = "DynabloxFace"
        decal.Face = Enum.NormalId.Front
        decal.Texture = config.assets.face_url
        decal.Parent = head
    end
    
    if torso and config.assets.tshirt_url then
        local decal = Instance.new("Decal")
        decal.Name = "DynabloxTShirt"
        decal.Face = Enum.NormalId.Front
        decal.Texture = config.assets.tshirt_url
        decal.Parent = torso
    end
    
    local pantsObj = character:FindFirstChildOfClass("Pants")
    if not pantsObj and config.assets.pants_url then
         pantsObj = Instance.new("Pants")
         pantsObj.Parent = character
    end
    if pantsObj and config.assets.pants_url then
        pantsObj.PantsTemplate = config.assets.pants_url
    end
end

local function onConnectionRejected()
    game:SetMessage("This game is not available. Please try another")
end

local function onConnectionFailed(_, id, reason)
    game:SetMessage("Failed to connect to the Game. (ID=" .. id .. ", " .. reason .. ")")
end

local function onConnectionAccepted(peer, replicator)
    local worldReceiver = replicator:SendMarker()
    local received = false
    local function onWorldReceived()
        received = true
    end
    worldReceiver.Received:connect(onWorldReceived)
    game:SetMessageBrickCount()
    
    while not received do
        workspace:ZoomToExtents()
        wait(0.5)
    end
    
    local player = Players.LocalPlayer
    game:SetMessage("Requesting character")
    replicator:RequestCharacter()
    game:SetMessage("Waiting for character")
    
    while not player.Character do
        player.Changed:wait()
    end
    
    game:ClearMessage()
    
    -- !!! ПРИМЕНЯЕМ КОСМЕТИКУ ПОСЛЕ ТОГО, КАК СЕРВЕР ОТДАЛ ПЕРСОНАЖА !!!
    wait(0.5)
    ApplyCosmetics(player.Character)
    print("[Dynablox] Connected and cosmetics applied!")
end

NetworkClient.ConnectionAccepted:connect(onConnectionAccepted)
NetworkClient.ConnectionRejected:connect(onConnectionRejected)
NetworkClient.ConnectionFailed:connect(onConnectionFailed)

game:SetMessage("Connecting to Server")
local success, errorMsg = pcall(function ()
    local player = Players.LocalPlayer
    if not player then
        player = Players:createLocalPlayer(0)
    end
    NetworkClient:connect("localhost", 53640, 0)
end)

if not success then
    game:SetMessage(errorMsg)
end